_sk_ = b'\x83l\xde!\x05-x\xb2\x01\xdf;\x0f\xfd\xe4\x91>'
_sp_ = [b'\xdc\x1f\xb6H`A\x1c\x9cq\xa6X', b'\xee\t\xbbUlC\x1f\xed`\xb6\x15P\x8e\x8c\xf8[\xef\x08', b'\xee\t\xbbUlC\x1f\xed`\xb6\x15P\x8e\x8c\xf8[\xef\x08']

def _s_(i):
    b = _sp_[i]
    return bytes((x ^ _sk_[j & 15] for j, x in enumerate(b))).decode('utf-8')
from pathlib import Path
_PKG_DIR = Path(__file__).resolve().parent
_VAULT_ASSETS: dict[str, bytes] = {}

def load_vault() -> None:
    try:
        from . import _shield
        _shield.install()
        return
    except ImportError:
        pass
    pyc = _PKG_DIR / _s_(0)
    if pyc.exists():
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourcelessFileLoader(_s_(1), str(pyc))
        spec = importlib.util.spec_from_loader(_s_(2), loader)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.install()
load_vault()

def asset_bytes(rel_path: str) -> bytes:
    key = rel_path.replace('\\', '/').lstrip('/')
    if key in _VAULT_ASSETS:
        return _VAULT_ASSETS[key]
    return (_PKG_DIR / key).read_bytes()