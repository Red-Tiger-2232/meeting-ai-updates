' Double-click on Windows to launch Meeting AI as a desktop window (no console window, no browser tab).
' Automatically creates a "Meeting AI" shortcut on the Desktop with the CP AXTRA icon on first run.
Option Explicit

Dim fso, shell, dir, pyw, ico, desktop, lnk
Set fso   = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
pyw = dir & "\.venv\Scripts\pythonw.exe"
ico = dir & "\meeting_ai\web\icon.ico"

If Not fso.FileExists(pyw) Then
    MsgBox "ไม่พบ .venv\Scripts\pythonw.exe" & vbCrLf & _
           "กรุณาติดตั้งด้วยคำสั่ง: py -m venv .venv && .venv\Scripts\pip install -r requirements.txt", _
           vbExclamation, "Meeting AI"
    WScript.Quit 1
End If

desktop = shell.SpecialFolders("Desktop")
lnk = desktop & "\Meeting AI.lnk"
If Not fso.FileExists(lnk) Then
    On Error Resume Next
    With shell.CreateShortcut(lnk)
        .TargetPath       = fso.GetSpecialFolder(1) & "\wscript.exe"
        .Arguments        = """" & WScript.ScriptFullName & """"
        .WorkingDirectory = dir
        .IconLocation     = ico & ",0"
        .Description      = "Meeting AI – MOM อัตโนมัติจาก Teams recording"
        .Save
    End With
    On Error GoTo 0
End If

shell.CurrentDirectory = dir
shell.Run """" & pyw & """ -m meeting_ai app", 0, False
