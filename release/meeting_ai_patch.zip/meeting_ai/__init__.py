_sk_ = b'\x03x\xe8\xfa\xa2&\xb2L<\xd1\x9a\xaf\xfc\x9a\xe3\xdd'
_sp_ = [b'\\\x0b\x80\x93\xc7J\xd6bL\xa8\xf9', b'n\x1d\x8d\x8e\xcbH\xd5\x13]\xb8\xb4\xf0\x8f\xf2\x8a\xb8o\x1c', b'n\x1d\x8d\x8e\xcbH\xd5\x13]\xb8\xb4\xf0\x8f\xf2\x8a\xb8o\x1c']

def _s_(i):
    b = _sp_[i]
    return bytes((x ^ _sk_[j & 15] for j, x in enumerate(b))).decode('utf-8')
from pathlib import Path
_PKG_DIR = Path(__file__).resolve().parent
_VAULT_ASSETS: dict[str, bytes] = {}

def load_vault() -> None:
    try:
        from . import _shield
        _shield.install()
        return
    except ImportError:
        pass
    pyc = _PKG_DIR / _s_(0)
    if pyc.exists():
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourcelessFileLoader(_s_(1), str(pyc))
        spec = importlib.util.spec_from_loader(_s_(2), loader)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.install()
load_vault()

def asset_bytes(rel_path: str) -> bytes:
    key = rel_path.replace('\\', '/').lstrip('/')
    if key in _VAULT_ASSETS:
        return _VAULT_ASSETS[key]
    return (_PKG_DIR / key).read_bytes()