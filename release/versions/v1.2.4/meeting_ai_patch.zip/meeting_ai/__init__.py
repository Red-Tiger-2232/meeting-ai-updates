_sk_ = b'[\xbaV\xcc8\xe5\xd3d@\xd8o\x8b\xa3\x96\xa2n'
_sp_ = [b'\x04\xc9>\xa5]\x89\xb7J0\xa1\x0c', b'6\xdf3\xb8Q\x8b\xb4;!\xb1A\xd4\xd0\xfe\xcb\x0b7\xde', b'6\xdf3\xb8Q\x8b\xb4;!\xb1A\xd4\xd0\xfe\xcb\x0b7\xde']

def _s_(i):
    b = _sp_[i]
    return bytes((x ^ _sk_[j & 15] for j, x in enumerate(b))).decode('utf-8')
from pathlib import Path
_PKG_DIR = Path(__file__).resolve().parent
_VAULT_ASSETS: dict[str, bytes] = {}

def load_vault() -> None:
    try:
        from . import _shield
        _shield.install()
        return
    except ImportError:
        pass
    pyc = _PKG_DIR / _s_(0)
    if pyc.exists():
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourcelessFileLoader(_s_(1), str(pyc))
        spec = importlib.util.spec_from_loader(_s_(2), loader)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.install()
load_vault()

def asset_bytes(rel_path: str) -> bytes:
    key = rel_path.replace('\\', '/').lstrip('/')
    if key in _VAULT_ASSETS:
        return _VAULT_ASSETS[key]
    return (_PKG_DIR / key).read_bytes()