_sk_ = b'\x8d\xfb\xf1%\x10\xa7+\xa2\xc2\xbf\xbdZ\x99\x82`\x94'
_sp_ = [b'\xd2\x88\x99Lu\xcbO\x8c\xb2\xc6\xde', b'\xe0\x9e\x94Qy\xc9L\xfd\xa3\xd6\x93\x05\xea\xea\t\xf1\xe1\x9f', b'\xe0\x9e\x94Qy\xc9L\xfd\xa3\xd6\x93\x05\xea\xea\t\xf1\xe1\x9f']

def _s_(i):
    b = _sp_[i]
    return bytes((x ^ _sk_[j & 15] for j, x in enumerate(b))).decode('utf-8')
from pathlib import Path
_PKG_DIR = Path(__file__).resolve().parent
_VAULT_ASSETS: dict[str, bytes] = {}

def load_vault() -> None:
    try:
        from . import _shield
        _shield.install()
        return
    except ImportError:
        pass
    pyc = _PKG_DIR / _s_(0)
    if pyc.exists():
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourcelessFileLoader(_s_(1), str(pyc))
        spec = importlib.util.spec_from_loader(_s_(2), loader)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.install()
load_vault()

def asset_bytes(rel_path: str) -> bytes:
    key = rel_path.replace('\\', '/').lstrip('/')
    if key in _VAULT_ASSETS:
        return _VAULT_ASSETS[key]
    return (_PKG_DIR / key).read_bytes()