_sk_ = b'\xd2\xbe\xc1\x94\xd9\xd1SG\xe4\xcc\xd7(\x9e\xab\xd2w'
_sp_ = [b'\x8d\xcd\xa9\xfd\xbc\xbd7i\x94\xb5\xb4', b'\xbf\xdb\xa4\xe0\xb0\xbf4\x18\x85\xa5\xf9w\xed\xc3\xbb\x12\xbe\xda', b'\xbf\xdb\xa4\xe0\xb0\xbf4\x18\x85\xa5\xf9w\xed\xc3\xbb\x12\xbe\xda']

def _s_(i):
    b = _sp_[i]
    return bytes((x ^ _sk_[j & 15] for j, x in enumerate(b))).decode('utf-8')
from pathlib import Path
_PKG_DIR = Path(__file__).resolve().parent
_VAULT_ASSETS: dict[str, bytes] = {}

def load_vault() -> None:
    try:
        from . import _shield
        _shield.install()
        return
    except ImportError:
        pass
    pyc = _PKG_DIR / _s_(0)
    if pyc.exists():
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourcelessFileLoader(_s_(1), str(pyc))
        spec = importlib.util.spec_from_loader(_s_(2), loader)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.install()
load_vault()

def asset_bytes(rel_path: str) -> bytes:
    key = rel_path.replace('\\', '/').lstrip('/')
    if key in _VAULT_ASSETS:
        return _VAULT_ASSETS[key]
    return (_PKG_DIR / key).read_bytes()