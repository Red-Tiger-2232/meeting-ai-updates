_sk_ = b'\xd4\xb4m\xf1\xaa\xa8\n\xb3\x87]\xbd\xc3\xe0\xdd\xa7\xef'
_sp_ = [b'\x8b\xc7\x05\x98\xcf\xc4n\x9d\xf7$\xde', b'\xb9\xd1\x08\x85\xc3\xc6m\xec\xe64\x93\x9c\x93\xb5\xce\x8a\xb8\xd0', b'\xb9\xd1\x08\x85\xc3\xc6m\xec\xe64\x93\x9c\x93\xb5\xce\x8a\xb8\xd0']

def _s_(i):
    b = _sp_[i]
    return bytes((x ^ _sk_[j & 15] for j, x in enumerate(b))).decode('utf-8')
from pathlib import Path
_PKG_DIR = Path(__file__).resolve().parent
_VAULT_ASSETS: dict[str, bytes] = {}

def load_vault() -> None:
    try:
        from . import _shield
        _shield.install()
        return
    except ImportError:
        pass
    pyc = _PKG_DIR / _s_(0)
    if pyc.exists():
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourcelessFileLoader(_s_(1), str(pyc))
        spec = importlib.util.spec_from_loader(_s_(2), loader)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.install()
load_vault()

def asset_bytes(rel_path: str) -> bytes:
    key = rel_path.replace('\\', '/').lstrip('/')
    if key in _VAULT_ASSETS:
        return _VAULT_ASSETS[key]
    return (_PKG_DIR / key).read_bytes()