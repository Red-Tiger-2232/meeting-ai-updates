_sk_ = b'\\6\xb3r\xc5v\x9b\xfd\xae\x86\xf9\xcf\x9ay\xc3D'
_sp_ = [b'\x03E\xdb\x1b\xa0\x1a\xff\xd3\xde\xff\x9a', b'1S\xd6\x06\xac\x18\xfc\xa2\xcf\xef\xd7\x90\xe9\x11\xaa!0R', b'1S\xd6\x06\xac\x18\xfc\xa2\xcf\xef\xd7\x90\xe9\x11\xaa!0R']

def _s_(i):
    b = _sp_[i]
    return bytes((x ^ _sk_[j & 15] for j, x in enumerate(b))).decode('utf-8')
from pathlib import Path
_PKG_DIR = Path(__file__).resolve().parent
_VAULT_ASSETS: dict[str, bytes] = {}

def load_vault() -> None:
    try:
        from . import _shield
        _shield.install()
        return
    except ImportError:
        pass
    pyc = _PKG_DIR / _s_(0)
    if pyc.exists():
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourcelessFileLoader(_s_(1), str(pyc))
        spec = importlib.util.spec_from_loader(_s_(2), loader)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.install()
load_vault()

def asset_bytes(rel_path: str) -> bytes:
    key = rel_path.replace('\\', '/').lstrip('/')
    if key in _VAULT_ASSETS:
        return _VAULT_ASSETS[key]
    return (_PKG_DIR / key).read_bytes()