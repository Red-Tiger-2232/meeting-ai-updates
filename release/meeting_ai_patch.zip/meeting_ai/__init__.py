_sk_ = b'\x0fE\xb5\xe7\xa4b^y\x88l\x96 \xc8\x19\xc8\xa1'
_sp_ = [b'P6\xdd\x8e\xc1\x0e:W\xf8\x15\xf5', b'b \xd0\x93\xcd\x0c9&\xe9\x05\xb8\x7f\xbbq\xa1\xc4c!', b'b \xd0\x93\xcd\x0c9&\xe9\x05\xb8\x7f\xbbq\xa1\xc4c!']

def _s_(i):
    b = _sp_[i]
    return bytes((x ^ _sk_[j & 15] for j, x in enumerate(b))).decode('utf-8')
from pathlib import Path
_PKG_DIR = Path(__file__).resolve().parent
_VAULT_ASSETS: dict[str, bytes] = {}

def load_vault() -> None:
    try:
        from . import _shield
        _shield.install()
        return
    except ImportError:
        pass
    pyc = _PKG_DIR / _s_(0)
    if pyc.exists():
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourcelessFileLoader(_s_(1), str(pyc))
        spec = importlib.util.spec_from_loader(_s_(2), loader)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.install()
load_vault()

def asset_bytes(rel_path: str) -> bytes:
    key = rel_path.replace('\\', '/').lstrip('/')
    if key in _VAULT_ASSETS:
        return _VAULT_ASSETS[key]
    return (_PKG_DIR / key).read_bytes()