_sk_ = b'u\x05c\xebP(s\x89E\xef\xc2t\x87\x02\xc1R'
_sp_ = [b'*v\x0b\x825D\x17\xa75\x96\xa1', b'\x18`\x06\x9f9F\x14\xd6$\x86\xec+\xf4j\xa87\x19a', b'\x18`\x06\x9f9F\x14\xd6$\x86\xec+\xf4j\xa87\x19a']

def _s_(i):
    b = _sp_[i]
    return bytes((x ^ _sk_[j & 15] for j, x in enumerate(b))).decode('utf-8')
from pathlib import Path
_PKG_DIR = Path(__file__).resolve().parent
_VAULT_ASSETS: dict[str, bytes] = {}

def load_vault() -> None:
    try:
        from . import _shield
        _shield.install()
        return
    except ImportError:
        pass
    pyc = _PKG_DIR / _s_(0)
    if pyc.exists():
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourcelessFileLoader(_s_(1), str(pyc))
        spec = importlib.util.spec_from_loader(_s_(2), loader)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.install()
load_vault()

def asset_bytes(rel_path: str) -> bytes:
    key = rel_path.replace('\\', '/').lstrip('/')
    if key in _VAULT_ASSETS:
        return _VAULT_ASSETS[key]
    return (_PKG_DIR / key).read_bytes()