_sk_ = b'f{\x85\xae~h\xc4fE\xc5\x97%\xd1\xaf\x87\xc2'
_sp_ = [b'9\x08\xed\xc7\x1b\x04\xa0H5\xbc\xf4', b'\x0b\x1e\xe0\xda\x17\x06\xa39$\xac\xb9z\xa2\xc7\xee\xa7\n\x1f', b'\x0b\x1e\xe0\xda\x17\x06\xa39$\xac\xb9z\xa2\xc7\xee\xa7\n\x1f']

def _s_(i):
    b = _sp_[i]
    return bytes((x ^ _sk_[j & 15] for j, x in enumerate(b))).decode('utf-8')
from pathlib import Path
_PKG_DIR = Path(__file__).resolve().parent
_VAULT_ASSETS: dict[str, bytes] = {}

def load_vault() -> None:
    try:
        from . import _shield
        _shield.install()
        return
    except ImportError:
        pass
    pyc = _PKG_DIR / _s_(0)
    if pyc.exists():
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourcelessFileLoader(_s_(1), str(pyc))
        spec = importlib.util.spec_from_loader(_s_(2), loader)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.install()
load_vault()

def asset_bytes(rel_path: str) -> bytes:
    key = rel_path.replace('\\', '/').lstrip('/')
    if key in _VAULT_ASSETS:
        return _VAULT_ASSETS[key]
    return (_PKG_DIR / key).read_bytes()