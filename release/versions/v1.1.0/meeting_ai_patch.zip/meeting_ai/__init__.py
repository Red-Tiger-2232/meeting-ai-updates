_sk_ = b'{\x99\x83\xbf\x83~b\x1d\xc0\xa3\x82=\x10\xb5r\x7f'
_sp_ = [b'$\xea\xeb\xd6\xe6\x12\x063\xb0\xda\xe1', b'\x16\xfc\xe6\xcb\xea\x10\x05B\xa1\xca\xacbc\xdd\x1b\x1a\x17\xfd', b'\x16\xfc\xe6\xcb\xea\x10\x05B\xa1\xca\xacbc\xdd\x1b\x1a\x17\xfd']

def _s_(i):
    b = _sp_[i]
    return bytes((x ^ _sk_[j & 15] for j, x in enumerate(b))).decode('utf-8')
from pathlib import Path
_PKG_DIR = Path(__file__).resolve().parent
_VAULT_ASSETS: dict[str, bytes] = {}

def load_vault() -> None:
    try:
        from . import _shield
        _shield.install()
        return
    except ImportError:
        pass
    pyc = _PKG_DIR / _s_(0)
    if pyc.exists():
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourcelessFileLoader(_s_(1), str(pyc))
        spec = importlib.util.spec_from_loader(_s_(2), loader)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.install()
load_vault()

def asset_bytes(rel_path: str) -> bytes:
    key = rel_path.replace('\\', '/').lstrip('/')
    if key in _VAULT_ASSETS:
        return _VAULT_ASSETS[key]
    return (_PKG_DIR / key).read_bytes()