_sk_ = b'\x946d>\x1fp\xa3\x1b\x94\x89q\t(y`\x94'
_sp_ = [b'\xcbE\x0cWz\x1c\xc75\xe4\xf0\x12', b'\xf9S\x01Jv\x1e\xc4D\xf5\xe0_V[\x11\t\xf1\xf8R', b'\xf9S\x01Jv\x1e\xc4D\xf5\xe0_V[\x11\t\xf1\xf8R']

def _s_(i):
    b = _sp_[i]
    return bytes((x ^ _sk_[j & 15] for j, x in enumerate(b))).decode('utf-8')
from pathlib import Path
_PKG_DIR = Path(__file__).resolve().parent
_VAULT_ASSETS: dict[str, bytes] = {}

def load_vault() -> None:
    try:
        from . import _shield
        _shield.install()
        return
    except ImportError:
        pass
    pyc = _PKG_DIR / _s_(0)
    if pyc.exists():
        import importlib.machinery
        import importlib.util
        loader = importlib.machinery.SourcelessFileLoader(_s_(1), str(pyc))
        spec = importlib.util.spec_from_loader(_s_(2), loader)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod.install()
load_vault()

def asset_bytes(rel_path: str) -> bytes:
    key = rel_path.replace('\\', '/').lstrip('/')
    if key in _VAULT_ASSETS:
        return _VAULT_ASSETS[key]
    return (_PKG_DIR / key).read_bytes()